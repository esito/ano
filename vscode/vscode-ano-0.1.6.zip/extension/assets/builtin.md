## String2Date
**String2Date** converts from string to date
## String2DateTime
**String2DateTime** converts from string to datetime
## String2Decimal
**String2Date** converts from string to date
## String2Integer
**String2Integer** converts from string to date
## String2Time
**String2Time** converts from string to date

## Email
**Email** transforms a string to valid email format
## CreditCard
**CreditCard** transforms the string to a creditcard number that validates MOD-10

## AllCombinations
**AllCombinations** creates rows for every combination of foreign key values
## EvenWithDeviation
**EvenWithDeviation** evenly spreads foreign key values for created records
## SimpleSpread
**SimpleSpread** randomly picks foreign key values for created records





